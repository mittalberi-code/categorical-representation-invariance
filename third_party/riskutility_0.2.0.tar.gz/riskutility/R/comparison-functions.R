#' riskutility: Disclosure Risk and Data Utility for Anonymized and Synthetic Data
#'
#' Provides a comprehensive toolkit for measuring disclosure risk and data utility
#' in anonymized and synthetic datasets. The package supports multivariate
#' Risk-Utility (R-U) evaluation following the framework described in
#' "Beyond the Trade-off Curve" (Thees, Mueller, Templ 2026).
#'
#' The package covers the following metric families:
#'
#' \strong{Attribution-based risk:} CAP-family measures (\code{\link{dcap}},
#' \code{\link{tcap}}, \code{\link{weap}}, \code{\link{disco}}) that assess
#' whether adversaries can infer sensitive attributes from quasi-identifiers.
#'
#' \strong{ML-based risk:} The \code{\link{rapid}} metric uses machine learning
#' models to predict sensitive attributes, capturing complex non-linear
#' relationships that CAP methods may miss.
#'
#' \strong{Distance-based risk:} Holdout-based metrics (\code{\link{dcr}},
#' \code{\link{nndr}}, \code{\link{ims}}) detect memorization by comparing
#' distances to training vs. holdout data.
#'
#' \strong{Utility measures:} Functions for assessing how well synthetic data
#' preserves the statistical properties of the original, including
#' \code{\link{pMSE}}, \code{\link{specks}}, \code{\link{hellinger}},
#' \code{\link{energy_distance}}, \code{\link{ci_proximity}},
#' \code{\link{mmd}}, \code{\link{tstr}}, \code{\link{copula_fidelity}},
#' \code{\link{tail_fidelity}}, \code{\link{subgroup_utility}},
#' \code{\link{regression_fidelity}}, \code{\link{contingency_fidelity}},
#' \code{\link{propscore}}, \code{\link{gower}}, and \code{\link{mqs}}.
#'
#' \strong{Privacy models:} Classical privacy model assessments including
#' \code{\link{kanonymity}}, \code{\link{ldiversity}},
#' \code{\link{individual_risk}}, and \code{\link{suda}}.
#'
#' \strong{Extended privacy risk:} Additional risk models including
#' \code{\link{tcloseness}}, \code{\link{nnaa}}, \code{\link{singling_out}},
#' \code{\link{linkability}}, \code{\link{population_uniqueness}},
#' \code{\link{epsilon_identifiability}}, \code{\link{delta_presence}},
#' \code{\link{hitting_rate}}, \code{\link{attacker_risk}},
#' \code{\link{drisk}}, \code{\link{domias}}, and \code{\link{mia_classifier}}.
#'
#' \strong{Information-theoretic measures:} Entropy and divergence measures
#' (\code{\link{KLDiv}}, \code{\link{JSDiv}}, \code{\link{RenyiEntropy}},
#' \code{\link{mutualInformation}}, \code{\link{information_surprisal}},
#' \code{\link{max_info_leakage}}) for quantifying information leakage.
#'
#' \strong{Comparison functions:} Direct comparison tools for original and
#' synthetic data including visualization, statistical tests, dimensionality
#' reduction, and predictive model comparisons.
#'
#' \strong{R-U mapping:} The \code{\link{rumap}} function provides comprehensive
#' multivariate Risk-Utility evaluation with Pareto frontier identification.
#'
#' @section Visualization Functions:
#' \describe{
#'   \item{\code{compare_histograms()}}{Compare distributions using histograms (weighted and unweighted, faceted).}
#'   \item{\code{compare_boxplots()}}{Compare numeric variable distributions using weighted/unweighted boxplots.}
#' }
#'
#' @section Statistical Tests:
#' \describe{
#'   \item{\code{compare_ks_test()}}{Kolmogorov-Smirnov test for comparing distributions.}
#'   \item{\code{compare_chisq_gof()}}{Chi-square Goodness-of-Fit test with multi-dimensional frequency tables (weighted/unweighted).}
#' }
#'
#' @section Distributional Comparisons:
#' \describe{
#'   \item{\code{compare_wasserstein()}}{Calculate Wasserstein distances between numeric or nominal variables.}
#'   \item{\code{compare_multivariate_distribution()}}{Compare joint distributions using Mahalanobis distance or mutual information.}
#' }
#'
#' @section Summary Statistics:
#' \describe{
#'   \item{\code{compare_means_frequencies()}}{Compare means, medians, robust statistics, skewness, kurtosis for numeric data, and frequencies for categorical data.}
#'   \item{\code{compare_correlation_matrices()}}{Compare correlations: Pearson, Spearman, robust correlations for numeric, categorical, and mixed data types.}
#'   \item{\code{compare_multivariate_summary_statistics()}}{Calculate joint summary statistics for numeric and categorical data.}
#' }
#'
#' @section Dimensionality Reduction:
#' \describe{
#'   \item{\code{compare_pca()}}{Principal Component Analysis comparison with biplot options.}
#'   \item{\code{compare_embedding()}}{t-SNE, UMAP, or Sammon's Mapping (MDS) visualizations for embedding comparisons.}
#' }
#'
#' @section Machine Learning and Predictive Modeling:
#' \describe{
#'   \item{\code{compare_model_performance()}}{Evaluate predictive model performance (accuracy, precision, recall, F1-score, AUC, R-squared, RMSE) using cross-validation.}
#'   \item{\code{compare_feature_importance()}}{Evaluate stability of feature importance measures from Random Forests, Decision Trees, Gradient Boosting, Permutation Importance, and SHAP values.}
#' }
#'
#' @section Dependencies:
#' The package builds on \code{ggplot2} and \code{data.table}; uses \code{VIM},
#' \code{MASS}, \code{randomForest}, and \code{ranger} for core computations; and
#' optionally integrates with \code{simPop}, \code{synthpop}, \code{Rtsne},
#' \code{uwot}, \code{caret}, and \code{robustbase} when installed.
#'
#' @section Missing-value handling:
#' Two parameter conventions are used deliberately, according to how much choice
#' a function offers. A logical \code{na.rm} (the standard R idiom) appears where
#' the only decision is whether to drop incomplete cases before computing a
#' statistic. A character selector appears where several treatments are
#' supported: \code{na} (\code{"remove"}, \code{"impute"}, \code{"stop"}, and in
#' \code{\link{pMSE}} additionally \code{"indicator"}) in \code{\link{propscore}},
#' \code{\link{pMSE}}, and \code{\link{mqs}}; and \code{na_strategy}
#' (\code{"constant"}, \code{"drop"}, \code{"median"}) in \code{\link{rapid}},
#' which acts specifically on the sensitive target attribute.
#'
#' @author Matthias Templ
#'
#' @seealso
#' \code{\link[ggplot2]{ggplot}}, \code{\link[data.table]{data.table}}
#'
#' @examples
#' # Create example datasets
#' set.seed(123)
#' X <- data.frame(
#'   income = rnorm(100, mean = 50000, sd = 10000),
#'   age = rnorm(100, mean = 40, sd = 10),
#'   gender = sample(c("Male", "Female"), 100, replace = TRUE),
#'   weight = runif(100, 0.5, 1.5)
#' )
#' Y <- data.frame(
#'   income = rnorm(100, mean = 48000, sd = 12000),
#'   age = rnorm(100, mean = 42, sd = 11),
#'   gender = sample(c("Male", "Female"), 100, replace = TRUE),
#'   weight = runif(100, 0.5, 1.5)
#' )
#'
#' # Example for histogram comparison
#' compare_histograms(X, Y, num_var = "income", cat_vars = c("gender"),
#'                    weight_X = "weight", weight_Y = "weight")
#'
#' # Example for PCA comparison
#' X_pca <- data.frame(
#'   income = rnorm(100, mean = 50000, sd = 10000),
#'   age = rnorm(100, mean = 40, sd = 10),
#'   expenditure = rnorm(100, mean = 2000, sd = 500)
#' )
#' Y_pca <- data.frame(
#'   income = rnorm(100, mean = 48000, sd = 12000),
#'   age = rnorm(100, mean = 42, sd = 11),
#'   expenditure = rnorm(100, mean = 2200, sd = 600)
#' )
#' res_pca <- compare_pca(X_pca, Y_pca,
#'                        vars = c("income", "age", "expenditure"),
#'                        biplot = TRUE)
#'
"_PACKAGE"
